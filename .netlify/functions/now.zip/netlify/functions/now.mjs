
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/now.ts
import { getStore } from "@netlify/blobs";
async function handler(req, context) {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }
  const authHeader = req.headers.get("authorization");
  const expectedToken = `Bearer ${process.env.NOW_API_TOKEN}`;
  if (!process.env.NOW_API_TOKEN || authHeader !== expectedToken) {
    return new Response("Unauthorized", { status: 401 });
  }
  try {
    const body = await req.json();
    const store = getStore("now_state");
    let currentData = {};
    try {
      const existingStr = await store.get("current", { type: "text" });
      if (existingStr) {
        currentData = JSON.parse(existingStr);
      }
    } catch (e) {
      console.log("No existing data or failed to parse");
    }
    const updatedData = {
      ...currentData,
      ...body,
      updated: (/* @__PURE__ */ new Date()).toISOString()
    };
    await store.setJSON("current", updatedData);
    return new Response(JSON.stringify({ success: true, data: updatedData }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
}
var config = {
  path: "/api/now"
};
export {
  config,
  handler as default
};
