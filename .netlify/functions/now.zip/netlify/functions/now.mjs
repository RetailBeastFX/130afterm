
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/now.ts
import { getStore } from "@netlify/blobs";
var EDITABLE_FIELDS = /* @__PURE__ */ new Set([
  "building",
  "trading",
  "working_on",
  "mood",
  "location"
]);
async function handler(req, context) {
  const store = getStore("now_state");
  if (req.method === "GET") {
    try {
      const existingStr = await store.get("current", { type: "text" });
      if (existingStr) {
        return new Response(existingStr, {
          headers: { "Content-Type": "application/json" }
        });
      }
      return new Response("{}", {
        headers: { "Content-Type": "application/json" }
      });
    } catch (e) {
      return new Response("{}", {
        headers: { "Content-Type": "application/json" }
      });
    }
  }
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }
  const authHeader = req.headers.get("authorization");
  const expectedToken = `Bearer ${process.env.NOW_API_TOKEN}`;
  if (!process.env.NOW_API_TOKEN || authHeader !== expectedToken) {
    return new Response("Unauthorized", { status: 401 });
  }
  try {
    const body = await req.json();
    const filteredBody = {};
    for (const [key, val] of Object.entries(body)) {
      if (EDITABLE_FIELDS.has(key) && typeof val === "string" && val.trim().length > 0 && val.length <= 120) {
        filteredBody[key] = val.trim();
      }
    }
    if (Object.keys(filteredBody).length === 0) {
      return new Response(JSON.stringify({ error: "No valid fields to update." }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const store2 = getStore("now_state");
    let currentData = {};
    try {
      const existingStr = await store2.get("current", { type: "text" });
      if (existingStr) {
        currentData = JSON.parse(existingStr);
      }
    } catch (e) {
      console.log("No existing data or failed to parse");
    }
    const updatedData = {
      ...currentData,
      ...filteredBody,
      updated: (/* @__PURE__ */ new Date()).toISOString()
    };
    await store2.setJSON("current", updatedData);
    return new Response(JSON.stringify({ success: true, data: updatedData }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
}
var config = {
  path: "/api/now"
};
export {
  config,
  handler as default
};
